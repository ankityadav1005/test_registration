from django.db import models


# from django.db.models import UserManager
# Create your models here.
class registration(models.Model):
    username = models.CharField(max_length=100, default="")
    email = models.EmailField(default="")
    name = models.CharField(max_length=100, default='')
    fathername = models.CharField(max_length=100, default='')
    image = models.ImageField(upload_to="images", default="")
    birthdate = models.DateField(null=True, blank=True, default="2000-12-23")

    def __unicode__(self):
        return self.username
