import io

from django.contrib import messages
from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import get_template
from xhtml2pdf import pisa

from user_auth.models import registration


# def home(request):
#     if request.user.is_authenticated:
#         print("Logged in")
#     else:
#         print("Not logged in")
#     # data = registration.objects.all()
#     # username = data.get('username')
#     # image = data.get('image')
#     # params={"username": username, "image": image}
#     return render(request=request, template_name='home.html')


def login_request(request):
    # return render(request, 'login.html')
    global in_data
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            messages.info(request, f"You are now logged in as {username}.")
            user1 = registration.objects.get(username=username)
            photo = user1.image.url
            username = user1.username
            name = user1.name
            email = user1.email
            fathername = user1.fathername
            birthdate = user1.birthdate
            photo_path = user1.image.path

            in_data = {"photo": photo, "username": username, "name": name, "email": email, "photo_path": photo_path,
                       "fathername": fathername, "birthdate": birthdate}
            # in_data = data.copy()
            return render(request, "home.html", context=in_data)

        else:
            messages.error(request, "Invalid username or password.")
    return render(request=request, template_name="login.html")


def register_request(request):
    # return render(request, 'register.html')
    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        name = request.POST.get('name')
        fathername = request.POST.get('father_name')
        img = request.FILES['image']
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            password = password1
            user = User.objects.create_user(username, email, password)
            user.save()
            registered_data = registration(name=name, username=username, email=email, fathername=fathername, image=img)
            registered_data.save()

        else:
            messages.info(request, "Password does not match")

    return render(request=request, template_name="register.html")  # , context={"register_form": form})


def logout_request(request):
    logout(request)
    messages.info(request, "You have successfully logged out.")
    return redirect(login_request)


def download_request(request):
    # buffer = io.BytesIO()
    # p = canvas.Canvas(buffer)
    # template = get_template('download.html')
    # p.drawString(100, 100, template)
    # p.showPage()
    # p.save()
    # buffer.seek(0)
    # return FileResponse(buffer, as_attachment=True, filename='hello.pdf')


    template = get_template('download.html')
    html = template.render(in_data)

    file = open('test.pdf', "w+b")
    pisaStatus = pisa.CreatePDF(html.encode('utf-8'), dest=file,
                                encoding='utf-8')

    file.seek(0)
    pdf = file.read()
    file.close()
    return HttpResponse(pdf, 'application/pdf')

